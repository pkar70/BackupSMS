﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace BackupSMS
{
    /// <summary>
    /// Provides application-specific behavior to supplement the default Application class.
    /// </summary>
    sealed partial class App : Application
    {

        #region "automat"


        /// <summary>
        /// Initializes the singleton application object.  This is the first line of authored code
        /// executed, and as such is the logical equivalent of main() or WinMain().
        /// </summary>
        public App()
        {
            this.InitializeComponent();
            this.Suspending += OnSuspending;
        }


        /// <summary>
        /// Invoked when the application is launched normally by the end user.  Other entry points
        /// will be used such as when the application is launched to open a specific file.
        /// </summary>
        /// <param name="e">Details about the launch request and process.</param>
        protected override void OnLaunched(LaunchActivatedEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;

            // Do not repeat app initialization when the Window already has content,
            // just ensure that the window is active
            if (rootFrame == null)
            {
                // Create a Frame to act as the navigation context and navigate to the first page
                rootFrame = new Frame();

                rootFrame.NavigationFailed += OnNavigationFailed;

                //if (e.PreviousExecutionState == ApplicationExecutionState.Terminated)
                //{
                //    //TODO: Load state from previously suspended application
                //}

                // Place the frame in the current Window
                Window.Current.Content = rootFrame;
            }

#if NETFX_CORE
            if (e != null && e.PrelaunchActivated == true) return;
#endif

            //if (e.PrelaunchActivated == false)
            //{
                if (rootFrame.Content == null)
                {
                    // When the navigation stack isn't restored navigate to the first page,
                    // configuring the new page by passing required information as a navigation
                    // parameter
                    rootFrame.Navigate(typeof(MainPage), e.Arguments);
                }
                // Ensure the current window is active
                Window.Current.Activate();
            //}
        }

        /// <summary>
        /// Invoked when Navigation to a certain page fails
        /// </summary>
        /// <param name="sender">The Frame which failed navigation</param>
        /// <param name="e">Details about the navigation failure</param>
        void OnNavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            throw new Exception("Failed to load Page " + e.SourcePageType.FullName);
        }

        /// <summary>
        /// Invoked when application execution is being suspended.  Application state is saved
        /// without knowing whether the application will be terminated or resumed with the contents
        /// of memory still intact.
        /// </summary>
        /// <param name="sender">The source of the suspend request.</param>
        /// <param name="e">Details about the suspend request.</param>
        private void OnSuspending(object sender, SuspendingEventArgs e)
        {
            var deferral = e.SuspendingOperation.GetDeferral();
            //TODO: Save application state and stop any background activity
            deferral.Complete();
        }

        #endregion

        #region "settingsy"
        public static bool GetSettingsBool(string sName, bool iDefault = false)
        {
            bool sTmp;

            sTmp = iDefault;

            if (Windows.Storage.ApplicationData.Current.RoamingSettings.Values.ContainsKey(sName))
                sTmp = System.Convert.ToBoolean(Windows.Storage.ApplicationData.Current.RoamingSettings.Values[sName].ToString(), System.Globalization.CultureInfo.CurrentCulture);
            if (Windows.Storage.ApplicationData.Current.LocalSettings.Values.ContainsKey(sName))
                sTmp = System.Convert.ToBoolean(Windows.Storage.ApplicationData.Current.LocalSettings.Values[sName].ToString(), System.Globalization.CultureInfo.CurrentCulture );

            return sTmp;
        }
        public static void SetSettingsBool(string sName, bool sValue, bool bRoam = false)
        {
            if (bRoam)
                Windows.Storage.ApplicationData.Current.RoamingSettings.Values[sName] = sValue.ToString();
            Windows.Storage.ApplicationData.Current.LocalSettings.Values[sName] = sValue.ToString();
        }

        public static string GetSettingsString(string sName, string sDefault = "")
        {
            string sTmp;

            sTmp = sDefault;

            if (Windows.Storage.ApplicationData.Current.RoamingSettings.Values.ContainsKey(sName))
                sTmp = Windows.Storage.ApplicationData.Current.RoamingSettings.Values[sName].ToString();
            if (Windows.Storage.ApplicationData.Current.LocalSettings.Values.ContainsKey(sName))
                sTmp = Windows.Storage.ApplicationData.Current.LocalSettings.Values[sName].ToString();

            return sTmp;
        }

        public static void SetSettingsString(string sName, string sValue, bool bRoam = false)
        {
            if (bRoam)
                Windows.Storage.ApplicationData.Current.RoamingSettings.Values[sName] = sValue;
            Windows.Storage.ApplicationData.Current.LocalSettings.Values[sName] = sValue;
        }
        public static int GetSettingsInt(string sName, int iDefault = 0)
        {
            int sTmp;

            sTmp = iDefault;

            {
                var withBlock = Windows.Storage.ApplicationData.Current;
                if (withBlock.RoamingSettings.Values.ContainsKey(sName))
                    sTmp = System.Convert.ToInt32(withBlock.RoamingSettings.Values[sName].ToString(), System.Globalization.CultureInfo.InvariantCulture);
                if (withBlock.LocalSettings.Values.ContainsKey(sName))
                    sTmp = System.Convert.ToInt32(withBlock.LocalSettings.Values[sName].ToString(), System.Globalization.CultureInfo.InvariantCulture);
            }

            return sTmp;
        }

        public static void SetSettingsInt(string sName, int sValue)
        {
            SetSettingsInt(sName, sValue, false);
        }

        public static void SetSettingsInt(string sName, int sValue, bool bRoam)
        {
            {
                var withBlock = Windows.Storage.ApplicationData.Current;
                if (bRoam)
                    withBlock.RoamingSettings.Values[sName] = sValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
                withBlock.LocalSettings.Values[sName] = sValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
            }
        }
        #endregion


        public static async void DialogBox(string sMsg)
        {
            Windows.UI.Popups.MessageDialog oMsg = new Windows.UI.Popups.MessageDialog(sMsg);
            await oMsg.ShowAsync();
        }

        public static async System.Threading.Tasks.Task<bool> DialogBoxYN(string sMsg, string sYes = "Tak", string sNo = "Nie")
        {
            Windows.UI.Popups.MessageDialog oMsg = new Windows.UI.Popups.MessageDialog(sMsg);
            Windows.UI.Popups.UICommand oYes = new Windows.UI.Popups.UICommand(sYes);
            Windows.UI.Popups.UICommand oNo = new Windows.UI.Popups.UICommand(sNo);
            oMsg.Commands.Add(oYes);
            oMsg.Commands.Add(oNo);
            oMsg.DefaultCommandIndex = 1;    // default: No
            oMsg.CancelCommandIndex = 1;
            Windows.UI.Popups.IUICommand oCmd = await oMsg.ShowAsync();
            if (oCmd == null)
                return false;
            if (oCmd.Label == sYes)
                return true;

            return false;
        }


        private static void IntLogAppend(string sStr)
        {
        }



        public static async System.Threading.Tasks.Task DodajTriggerPolnocny()
        {
            IntLogAppend("DodajTriggerPolnocny - START");
            Windows.ApplicationModel.Background.BackgroundAccessStatus oBAS;
            oBAS = await Windows.ApplicationModel.Background.BackgroundExecutionManager.RequestAccessAsync();

            if ((oBAS == Windows.ApplicationModel.Background.BackgroundAccessStatus.AlwaysAllowed) | 
                (oBAS == Windows.ApplicationModel.Background.BackgroundAccessStatus.AllowedSubjectToSystemPolicy))
            {
                // ' https://docs.microsoft.com/en-us/windows/uwp/launch-resume/create-And-register-an-inproc-background-task

                // IntLogAppend("DTS - removing tasks")
                // po co, skoro OneShot?
                // For Each oTask In BackgroundTaskRegistration.AllTasks
                // If oTask.Value.Name = "PKARsmsBackup_Daily" Then oTask.Value.Unregister(True)
                // Next

                IntLogAppend("DTS - building task");
                Windows.ApplicationModel.Background.BackgroundTaskBuilder builder = new Windows.ApplicationModel.Background.BackgroundTaskBuilder();
                Windows.ApplicationModel.Background.BackgroundTaskRegistration oRet;

                IntLogAppend("DTS - calculating mins");
                // Dim oDate1 = Date.Now.AddHours(1).AddDays(1)    ' 1h - zeby na nastepną dobę, +1 dzien (bez +1h by trafiał na 20 minut pozniej!)
                // Dim oDate0 = New Date(oDate1.Year, oDate1.Month, oDate1.Day)    ' polnoc
                // oDate0 = oDate0.AddMinutes(-20)
                // Dim oDate0 = New Date(oDate1.Year, oDate1.Month, oDate1.Day)    ' polnoc
                DateTime oDateMew;
                if (DateTime.Now.Hour > 20)
                    oDateMew = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 40, 0).AddDays((double)1);
                else
                    oDateMew = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 40, 0);// DZIS

                int iMin = (int)(oDateMew - DateTime.Now).TotalMinutes;
                IntLogAppend(" waiting mins:" + iMin.ToString(System.Globalization.CultureInfo.InvariantCulture));
                // Dim iMin = (24 * 60) - 20    ' 24 godziny po 60 minut bez 20 minut; czyli czas uruchomienia
                // iMin -= Date.Now.Hour() * 60  ' odjąć aktualny czas
                // iMin -= Date.Now.Minute()

                builder.SetTrigger(new Windows.ApplicationModel.Background.TimeTrigger((uint)iMin, true));
                builder.Name = "PKARsmsBackup_Daily";
                oRet = builder.Register();
            }
            else
                IntLogAppend("DTS - oBAS.Status = " + oBAS.ToString());
            // return default(Task);
        }

        private Windows.ApplicationModel.Background.BackgroundTaskDeferral moTimerDeferal = null;

        protected override async void OnBackgroundActivated(BackgroundActivatedEventArgs args)
        {
            moTimerDeferal = args.TaskInstance.GetDeferral();
            IntLogAppend("OnBackActiv - START");
            DateTime oDate = DateTime.Now.AddHours((double)-DateTime.Now.Hour - 1);
            await WyciagnijSMS(oDate, true, false, null, "");
            await DodajTriggerPolnocny();
            moTimerDeferal.Complete();
        }


        private static async System.Threading.Tasks.Task<string> PhoneNo2ContactName(string sPhoneNumber)
        {
            // https://stackoverflow.com/questions/34953283/how-to-get-contact-by-phone-number
            if (string.IsNullOrEmpty(sPhoneNumber))
                return "";
            try
            {
                Windows.ApplicationModel.Contacts.ContactStore oStore = await Windows.ApplicationModel.Contacts.ContactManager.RequestStoreAsync(Windows.ApplicationModel.Contacts.ContactStoreAccessType.AllContactsReadOnly);
                Windows.ApplicationModel.Contacts.ContactReader oContactRdr = oStore.GetContactReader(new Windows.ApplicationModel.Contacts.ContactQueryOptions(sPhoneNumber));
                Windows.ApplicationModel.Contacts.ContactBatch oBatch = await oContactRdr.ReadBatchAsync();
                if (oBatch.Contacts.Count < 1)
                    return "";
                return oBatch.Contacts[0].DisplayName;
            }
            catch 
            {
                return "????";
            }
        }

        public static async System.Threading.Tasks.Task<Windows.Storage.StorageFolder> GetSDcardFolder()
        {
            try
            {
                Windows.Storage.StorageFolder externalDevices = Windows.Storage.KnownFolders.RemovableDevices;
                System.Collections.Generic.IReadOnlyList<Windows.Storage.StorageFolder> oCards = await externalDevices.GetFoldersAsync();
                return oCards.FirstOrDefault();
                //return null;
            }
            catch 
            {
            }

            return null;
        }


        public static async System.Threading.Tasks.Task<int> WyciagnijSMS(DateTime oDate, bool bInTimer, bool bShowSince, TextBlock uiMsgCnt, string sSufix)
        {
            IntLogAppend("WyciagnijSMS - START");
            // Dim oTextBox As TextBlock = Nothing

            // Try

            // If Not bInTimer Then
            // IntLogAppend("WSMS - not timer")
            // ' znajdz control o nazwie uiMsgCnt
            // Dim oStackPanel As StackPanel = TryCast(TryCast(TryCast(Window.Current.Content, Frame).Content.Content, Grid).Children(0), StackPanel)
            // For Each oChld As UIElement In oStackPanel.Children
            // Dim oTmp As TextBlock = TryCast(oChld, TextBlock)
            // If oTmp IsNot Nothing Then
            // If oTmp.Name = "uiMsgCnt" Then
            // oTextBox = oTmp
            // Exit For
            // End If
            // End If
            // Next
            // End If
            // Catch ex As Exception
            // ' w razie błędu oTextBox bedzie = Nothing, ale nie wyleci program
            // End Try

            // If uiProcesuje IsNot Nothing Then
            // uiProcesuje.Visibility = Visibility.Visible
            // uiProcesuje.IsActive = True
            // End If

            int iRet = -1;

            bool bError = false;
            Windows.ApplicationModel.Chat.ChatMessageReader oRdr = null;
            try
            {
                Windows.ApplicationModel.Chat.ChatMessageStore oStore = await Windows.ApplicationModel.Chat.ChatMessageManager.RequestStoreAsync();
                if (oStore == null)
                {
                    if (uiMsgCnt != null) DialogBox("No permission (or this is not a phone)");
                    return -1;
                }

                IntLogAppend("WSMS - got oStore");
                
                oRdr = oStore.GetMessageReader();
                IntLogAppend("WSMS - got oRdr");
            }
            catch 
            {
                bError = true;
            }

            if (bError)
            {
                if (uiMsgCnt != null)
                    uiMsgCnt.Text = "ERROR - check permissions?";
                // If uiProcesuje IsNot Nothing Then
                // uiProcesuje.Visibility = Visibility.Visible
                // uiProcesuje.IsActive = True
                // End If
                return -1;
            }

            string sTxt = "";
            int iGuard = 0;

            int iLastRunCnt = GetSettingsInt("lastRunCnt");
            string sLastRun = "";
            if (bShowSince && iLastRunCnt > 0)
                sLastRun = " (/" + iLastRunCnt.ToString(System.Globalization.CultureInfo.InvariantCulture) + ")";


            while (iGuard < 10000)
            {
                iGuard = iGuard + 1;
                if (uiMsgCnt != null)
                    uiMsgCnt.Text = iGuard.ToString(System.Globalization.CultureInfo.InvariantCulture) + sLastRun;
                IntLogAppend("WSMS - loop, iGuard=" + iGuard);

                System.Collections.Generic.IReadOnlyList<Windows.ApplicationModel.Chat.ChatMessage> oMsgList; // = default(IReadOnlyList<ChatMessage>);
                try     // Try dodane 20190223
                {
                    oMsgList = await oRdr.ReadBatchAsync();
                }
                catch 
                {
                    if (uiMsgCnt != null)
                        uiMsgCnt.Text = "ERROR - check permissions?";
                    // If uiProcesuje IsNot Nothing Then
                    // uiProcesuje.Visibility = Visibility.Visible
                    // uiProcesuje.IsActive = True
                    // End If
                    return -1;
                }

                if (oMsgList.Count < 1)
                    break;
                // Folder	From	FromAddress	To	ToAddress	Date	Message
                foreach (Windows.ApplicationModel.Chat.ChatMessage oMsg in oMsgList)
                {
                    if (oMsg.IsIncoming)
                        sTxt = sTxt + "Inbox|";
                    else
                        sTxt = sTxt + "Outbox|";

                    sTxt = sTxt + await PhoneNo2ContactName(oMsg.From) + "|";   // from
                    sTxt = sTxt + oMsg.From + "|";   // fromAddress

                    string sRcptNum = "";
                    string sRcptName = "";
                    foreach (string sRcpt in oMsg.Recipients)
                    {
                        sRcptNum = sRcptNum + sRcpt;
                        sRcptName = sRcptName + await PhoneNo2ContactName(sRcpt);
                    }

                    sTxt = sTxt + sRcptName + "|";   // from
                    sTxt = sTxt + sRcptNum + "|";   // fromAddress

                    try // 20180117: jakby LocalTimeStamp miał być null (np.)...
                    {
                        sTxt = sTxt + oMsg.LocalTimestamp.ToString("dd/MM/yyyy HH:mm:ss") + "|";
                    }
                    catch 
                    {
                        sTxt = sTxt + "|";
                    }// empty date

                    try // 20180117: jakby Body miał być null (np.)...
                    {
                        sTxt = sTxt + oMsg.Body;
                    }
                    catch 
                    {
                    }

                    // <Message><Recepients /><Body>A jak chcesz spędzić ten czas.</Body><IsIncoming>true</IsIncoming><IsRead>true</IsRead><Attachments /><LocalTimestamp>131606927899116393</LocalTimestamp><Sender>+48531346962</Sender></Message>

                    // 20190825: sTxt += oMsg.Body + "\n"; // Constants.vbCrLf;
                    sTxt += "\n";
                    iRet++;

                    if (oMsg.LocalTimestamp < oDate)
                        break;
                }
            }

            if (bShowSince)
                SetSettingsInt("lastRunCnt", iGuard);

            if (uiMsgCnt != null)
                uiMsgCnt.Text = "Saving...";

            Windows.Storage.StorageFolder sdCard = await GetSDcardFolder();

            if (sdCard == null)
            {
                if (uiMsgCnt != null)
                    uiMsgCnt.Text = "Cannot save - no SD card?";
                // If uiProcesuje IsNot Nothing Then
                // uiProcesuje.Visibility = Visibility.Visible
                // uiProcesuje.IsActive = True
                // End If
                return -1;    // error - nie ma karty
            }

            Windows.Storage.StorageFolder oFold = await sdCard.CreateFolderAsync("DataLogs", Windows.Storage.CreationCollisionOption.OpenIfExists);
            if (oFold == null)
                return -1;
            oFold = await oFold.CreateFolderAsync("BackupSMS", Windows.Storage.CreationCollisionOption.OpenIfExists);
            if (oFold == null)
                return -1;
            oFold = await oFold.CreateFolderAsync(DateTime.Now.ToString("yyyy"), Windows.Storage.CreationCollisionOption.OpenIfExists);
            if (oFold == null)
                return -1;
            oFold = await oFold.CreateFolderAsync(DateTime.Now.ToString("MM"), Windows.Storage.CreationCollisionOption.OpenIfExists);
            if (oFold == null)
                return -1;

            string sFile = "SMS " + DateTime.Now.ToString("yyyy.MM.dd-HH.mm.ss") + ".csv";
            Windows.Storage.StorageFile oFile = await oFold.CreateFileAsync(sFile, Windows.Storage.CreationCollisionOption.OpenIfExists);
            await Windows.Storage.FileIO.WriteTextAsync(oFile, sTxt);

            if (uiMsgCnt != null)
                uiMsgCnt.Text = "Saved " + iRet.ToString(System.Globalization.CultureInfo.InvariantCulture) + " messages.";

            return iRet;
            //return default(Task);
        }
    }
}



